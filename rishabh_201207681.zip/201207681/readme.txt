Just keep the zip and the script within this jar in the same folder.
Kindly input as stated in the document. Might not be able to handle all the exceptions

All the functionalities are dealt in it. It runs on most of the hosts, the ip of the machine as well as on the localhost. Port 80 is by default. Also runs on port 8080.
Output in Json format
x64 taken by default.
no rule for 32 bit system.
