#!/bin/bash
unzip 201207681.zip
export VAR="$(ifconfig br0 | sed -n '/inet /{s/.*addr://;s/ .*//;p}')"
sudo chmod 777 /var/libvirt/images
sudo /bin/rm /var/libvirt/images/make
sudo /bin/rm /var/libvirt/images/host*
sudo /bin/rm /var/libvirt/images/Ready*
sudo /bin/rm -rf /var/libvirt/images/tomcat
export schedular=1
sudo echo -e "$1\n$2\n$3\n$schedular" > /var/libvirt/images/make
cd 201207681/
tar xzvf $PWD/apache-tomcat-7.0.30.tar.gz
cd ../
sudo mv $PWD/201207681/apache-tomcat-7.0.30 /var/libvirt/images/tomcat
export CATALINA_HOME=/var/libvirt/images/tomcat
sudo iptables -t nat -A OUTPUT -d localhost -p tcp --dport 80 -j REDIRECT --to-ports 8080
sudo iptables -t nat -A OUTPUT -d $VAR -p tcp --dport 80 -j REDIRECT --to-ports 8080
cp $PWD/201207681/*.jar /var/libvirt/images/tomcat/lib/
cp $PWD/201207681/*.war /var/libvirt/images/tomcat/webapps/
/var/libvirt/images/tomcat/bin/startup.sh
